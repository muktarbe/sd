// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Person person1 = new Person(" Саша ", 12, " мужик ", " Рассия ", " Масква ");
        Person person2 = new Person(" Бекзат ", 19, " мужик ", " Рассия ", " Масква ");
        Person person3 = new Person(" Карина  ", 25, " девачка ", " Туюрк ", "  ");
        Person person4 = new Person(" Миша ", 100, " мужик ", " Рассия ", " Масква ");
        Person person5 = new Person(" Владимер ", 21, " мужик ", " Рассия ", " Масква ");
        //-----------------------------
        Person person6 = new Person();
        person6.setName(" Залкар ");
        person6.setAge(17);
        person6.setGender(" мальчик ");
        person6.setCountry(" Кыргыз ");
        person6.setCity(" Джалал-абад ");
        //-----------------------------
        Person person7 = new Person();
        person7.setName(" Зафар ");
        person7.setAge(18);
        person7.setGender(" мальчик ");
        person7.setCountry(" Казак ");
        person7.setCity(" Аматы ");
        //-----------------------------
        Person person8 = new Person();
        person8.setName(" Настя ");
        person8.setAge(23);
        person8.setGender(" девочка ");
        person8.setCountry(" Рассия ");
        person8.setCity(" Иркутская ");
        //-----------------------------
        Person person9 = new Person();
        person9.setName(" Арсен ");
        person9.setAge(65);
        person9.setGender(" мальчик ");
        person9.setCountry(" Татар ");
        person9.setCity("  ");
        //-----------------------------
        Person person0 = new Person();
        person0.setName(" Байэл ");
        person0.setAge(10);
        person0.setGender(" мужик ");
        person0.setCountry(" Кыргыз ");
        person0.setCity(" Ош ");
        //--------------------------------
        Person[] people = {person1, person2, person3, person4, person5, person6, person7, person8, person9, person0};
        //--------------------------------
        System.out.println("All People: ");
        for (Person ddd : people) {
            System.out.println(ddd.toString());
        }
        //------------------------------------------
        System.out.println("----------------------------------------------------------------");
        Person oldestPerson = getMaxAgePerson(people);
        System.out.println("The oldest Person: ");
        System.out.println(oldestPerson.toString());
        //------------------------------------------
        Person[] females = getPeopleByGender(people, "Female");
        Person[] males = getPeopleByGender(people, "Male");
        System.out.println("----------------------------------------------------------------");
        System.out.println("Female persons:");
        for (Person female : females) {
            System.out.println(female.toString());
        }
        System.out.println("----------------------------------------------------------------");
        //---------------------------------
        System.out.println("Male persons:");
        for (Person male : males) {
            System.out.println(male.toString());
        }
    }
    public static Person getMaxAgePerson(Person[] people) {
        Person maxAgePerson = people[0];
        for (int i = 1; i < people.length; i++) {
            if (people[i].getAge() > maxAgePerson.getAge()) {
                maxAgePerson = people[i];
            }
        }
        return maxAgePerson;
    }
    //----------------------------------------------------------------------
    public static Person[] getPeopleByGender(Person[] people, String gender) {
        int count = 0;
        for (Person person3 : people) {
            if (person3.getGender().equals(gender)) {
                count++;
            }
        }
        //--------------------------------------------------------------------
        Person[] result = new Person[count];
        int index = 0;
        for (Person person3 : people) {
            if (person3.getGender().equals(gender)) {
                result[index] = person3;
                index++;
            }
        }
        return result;
    }
}
